# 🐛 DEBUG REPORT - Background Context Menu Không Hiển Thị

## 📊 Tình Trạng Hiện Tại

**Triệu chứng**: Click chuột phải vào nền MXH không hiển thị context menu

**Debug logs cho thấy**:
```
✅ Event listener ĐANG hoạt động
✅ JavaScript set display = 'block' THÀNH CÔNG
✅ Menu có position left/top đúng (867px, 705px)
✅ Menu có kích thước (width: 229.5px, height: 130px)
❌ Menu KHÔNG hiển thị trên màn hình
```

## 🔍 Các Thành Phần Đã Kiểm Tra

### 1. HTML Structure (Line 143-165)
```html
<div id="mxh-background-context-menu" class="custom-context-menu" style="display: none;">
    <div class="menu-item has-submenu" data-action="view-filter">
        <span><i class="bi bi-eye me-2"></i>Xem</span>
        <div class="submenu">
            <div class="menu-item" data-action="view-default">
                <span id="view-default-check">✓ </span>Mặc định
            </div>
            <div class="menu-item" data-action="view-card2">
                <span id="view-card2-check"></span>Card 2
            </div>
            <div class="menu-item" data-action="view-card3">
                <span id="view-card3-check"></span>Card 3
            </div>
        </div>
    </div>
    <div class="menu-item" data-action="view-mode">
        <i class="bi bi-grid-3x3-gap me-2"></i>Chế Độ Xem
    </div>
    <div class="menu-item" data-action="add-account">
        <i class="bi bi-plus-lg me-2"></i>+ Thêm Tài Khoản MXH
    </div>
</div>
```
**Status**: ✅ OK - Cấu trúc đúng

### 2. CSS Styles (Line 506-556)
```css
.custom-context-menu {
    position: fixed !important;
    z-index: 10000 !important;
    background: #2c3340 !important;
    border: 1px solid #444a59 !important;
    border-radius: 8px !important;
    padding: 4px !important;
    min-width: 200px !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4) !important;
}

.custom-context-menu .menu-item {
    padding: 8px 12px;
    color: #e6e6e6;
    cursor: pointer;
    border-radius: 4px;
    transition: background 0.2s;
    position: relative;
    white-space: nowrap;
}

.custom-context-menu .menu-item:hover {
    background: rgba(0, 224, 255, 0.15);
    color: #00e0ff;
}

.custom-context-menu .menu-item.has-submenu>span::after {
    content: '▶';
    float: right;
    margin-left: 12px;
    font-size: 0.8em;
    opacity: 0.6;
}

.custom-context-menu .submenu {
    position: absolute;
    left: calc(100% - 2px);
    top: -4px;
    margin-left: 0;
    display: none;
    background: #2c3340;
    border: 1px solid #444a59;
    border-radius: 8px;
    padding: 4px;
    min-width: 180px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    z-index: 10001;
}

.custom-context-menu .menu-item.has-submenu:hover>.submenu,
.custom-context-menu .submenu:hover {
    display: block !important;
}

.custom-context-menu .submenu .menu-item {
    padding: 6px 10px;
    font-size: 0.9em;
}
```
**Status**: ⚠️ KHÔNG CÓ display rule cho .custom-context-menu (để JS control)

### 3. JavaScript Event Listener (Line 3484-3540)
```javascript
document.getElementById('mxh-accounts-container').addEventListener('contextmenu', function (event) {
    // Only show if NOT clicked on a card
    const clickedCard = event.target.closest('.card');
    const clickedOnContainer = event.target.id === 'mxh-accounts-container';
    const clickedOnRow = event.target.classList.contains('row');
    
    if (!clickedCard && (clickedOnContainer || clickedOnRow)) {
        event.preventDefault();

        // Hide all other context menus
        document.querySelectorAll('.custom-context-menu').forEach(menu => {
            menu.style.display = 'none';
        });

        // Show background context menu
        const contextMenu = document.getElementById('mxh-background-context-menu');
        contextMenu.style.display = 'block';

        // Smart positioning to avoid overflow
        contextMenu.style.left = event.pageX + 'px';
        contextMenu.style.top = event.pageY + 'px';
        // ... positioning logic
    }
});
```
**Status**: ✅ OK - Event hoạt động, JS set display đúng

## 🤔 CÁC GIẢ THUYẾT VỀ NGUYÊN NHÂN

### Giả thuyết 1: CSS Cascade/Specificity Issue
- Có thể có CSS rule khác override display
- Bootstrap hoặc base.html có thể có CSS conflict

### Giả thuyết 2: Z-index Stacking Context
- Menu có z-index: 10000 nhưng vẫn bị che
- Có thể parent element tạo stacking context mới

### Giả thuyết 3: Visibility/Opacity Hidden
- Menu có display: block nhưng visibility: hidden?
- Hoặc opacity: 0?

### Giả thuyết 4: Position Context Issue
- Menu là position: fixed nhưng bị đẩy ra ngoài viewport
- Transform hoặc filter trên parent gây lỗi fixed positioning

### Giả thuyết 5: Bootstrap Override
- Bootstrap modal/dropdown có CSS conflict với custom-context-menu
- Bootstrap JS có thể ẩn menu khi click

## 🔧 CÁC BƯỚC ĐÃ THỰC HIỆN

1. ✅ Thêm CSS đầy đủ cho `.custom-context-menu`
2. ✅ Thêm submenu hover logic
3. ✅ Fix event listener logic (không show khi click vào card)
4. ✅ Thêm debug logs
5. ✅ Xóa `display: none !important` khỏi CSS (để JS control)

## 🎯 CÁC BƯỚC TIẾP THEO ĐỀ XUẤT

### Test 1: Inline Style Override
Thử force inline style với nhiều properties:
```javascript
contextMenu.style.cssText = 'display: block !important; position: fixed !important; z-index: 99999 !important; background: red !important;';
```

### Test 2: Check Computed Style
Thêm debug để xem computed style thực tế:
```javascript
const computed = window.getComputedStyle(contextMenu);
console.log('Computed display:', computed.display);
console.log('Computed visibility:', computed.visibility);
console.log('Computed opacity:', computed.opacity);
console.log('Computed z-index:', computed.zIndex);
```

### Test 3: Check Parent Stacking
Kiểm tra parent elements:
```javascript
let parent = contextMenu.parentElement;
while (parent) {
    const style = window.getComputedStyle(parent);
    console.log(parent.tagName, {
        position: style.position,
        zIndex: style.zIndex,
        opacity: style.opacity,
        display: style.display
    });
    parent = parent.parentElement;
}
```

### Test 4: Simple HTML Test
Tạo menu test đơn giản nhất:
```html
<div id="test-menu" style="position: fixed; top: 100px; left: 100px; background: red; color: white; padding: 20px; z-index: 99999; display: none;">
    TEST MENU
</div>
```
Và test xem có hiển thị không khi set display: block

## 📦 FILES LIÊN QUAN

- `app/templates/mxh.html` - File chính cần debug
- `app/templates/layouts/base.html` - Base layout, có context menu khác
- `app/mxh_api.py` - Backend API
- `app/mxh_routes.py` - Routes

## 📊 DEBUG DATA TỪ CONSOLE

```
🔍 Right-click detected on: <div class="row g-2">
🔍 Target ID: (empty)
🔍 Closest card: null
🔍 Showing background context menu
🔍 Context menu element: <div id="mxh-background-context-menu" ...>
🔍 Menu display before: none
🔍 Menu display after: block  <- Set thành công!
🔍 Menu position: {left: 867, top: 705}
🔍 Menu rect: DOMRect {x: 867, y: 705, width: 229.5, height: 130, ...}
```

**Kết luận từ debug**: 
- Element TỒN TẠI ✅
- Display được SET = 'block' ✅
- Position CÓ GIÁ TRỊ hợp lệ ✅
- Kích thước > 0 ✅
- **NHƯNG KHÔNG HIỂN THỊ** ❌

## 💡 KHUYẾN NGHỊ URGENT

Cần thực hiện **Test 2** (Check Computed Style) ngay để xem style thực tế browser đang apply là gì. Rất có thể có một CSS rule nào đó đang override mà chúng ta chưa phát hiện.

---
**Date**: 2025-11-04
**Status**: 🔴 CHƯA GIẢI QUYẾT

